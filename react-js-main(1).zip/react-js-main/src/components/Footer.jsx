import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
        <footer className="bg-gray-800 text-white py-4">
            <div className="container mx-auto px-4">
            <p>&copy; 2024 My Footer</p>
            </div>
        </footer>
    )
  }
}

export default Footer