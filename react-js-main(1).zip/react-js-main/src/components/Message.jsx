import React from 'react'

function Message(props) {
  return (
    <div><h1>This is a function components</h1></div>
  )
}

export default Message